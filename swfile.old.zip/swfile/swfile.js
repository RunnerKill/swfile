/**
 * @title “附件”功能封装
 * @version 2.2.1 兼容IE8
 * @author Xiaojie.Xu
 */
(function ($) {
    var root = function(){var a=location.href;var b=location.pathname;var c=a.substring(0,a.indexOf(b));var d=b.substring(0,b.substr(1).indexOf('/')+1);return c+d+"/";}();
    var defaults = {
    	server : null,				// 服务器地址（附件服务器地址），如 http://ip:port
    	project : null,				// 所属项目
    	theme : "default",			// 主题样式名，对应swfile.skin.css中样式
    	domain : "file",			// 服务器域名（附件服务项目名），如 domain
    	proxy : "File",				// 代理Servlet名称
    	multiple : true,			// 是否可多选
    	onInit : function() {},	        // 初始化完毕回调
    	onLoad : function(files) {},	// 加载完成回调
    	onUpload : function(files) {},	// 上传完成回调
    	onPreview : function(url, funDownload, funDelete) {},	// 预览回调
    	onDownload : function(id) {},	// 下载开始回调
    	onDelete : function(file) {},	// 删除完成回调
    	onError : function(status) {}	// 错误提示回调，status: 300 - 服务器参数未设置， 301 - 类型不正确
    };
    var CONSTANTS = {
    	CONTAINER_CLASS : "sowell-file", // 样式名
    	URL_PREFIX : null, // 请求前缀
    	REQUEST_NAME : "/swfile", // 服务器端Controller名
    	CACHE_KEY : "CACHE_KEY",
    	MAX_LIMIT : 20,			// 默认最大限制上传数
    	NO_EDIT : "readonly"    // 只读样式
    };
    var css = {
        "display" : "block",
        "overflow" : "hidden",
        "border" : "none",
        "margin" : "0",
        "padding" : "0",
        "position" : "absolute",
        "top" : "0",
        "left" : "0",
        "width" : "100%",
        "height" : "150px",
        "opacity" : "0",
        "cursor" : "pointer"
    };
    var idocs = []; // iframe的document对象列表
    var ftype = {}; // 支持判断的文件类型，从服务器加载
    var cur_options = null;		// 保留options参数，用于回调函数中
    var $cur_containers = null; // 保留$(this)参数，用于回调函数中
    $.fn.extend({
    	swfile : function(options) { // 初始化
    		if($(this).length < 1) return false;
    		options = $.extend({}, defaults, options);
    		if(options.server == null) {
    			options.onError(300);
    			return false;
    		}
    		// 服务器端请求前缀
    		CONSTANTS.URL_PREFIX = options.server + "/" + options.domain + CONSTANTS.REQUEST_NAME;
    		// 定位代理请求
            options.proxy = root + options.proxy;
            // 保存当前opt和container
            cur_options = options;
            $cur_containers = $(this);
			// 从服务器加载到缓存
			_swfile_acts.init();
    	}
    });
    
    // 请求方法（私有）
    var _swfile_acts = {
        // 初始化
        init : function() {
            idocs = []; // 重置
            initHtml(); // 初始化html结构
            $cur_containers.addClass("loading load");
            sendRequest("/init", {
                proxy : cur_options.proxy
            }, 0, "swinit_frame");
        },
        // 加载数据
        load : function() {
            $cur_containers.addClass("loading load");
            sendRequest("/load", {
                key : $cur_containers.data("data-key"),
                proxy : cur_options.proxy,
                fidStr : $cur_containers.map(function() { // 遍历请求
                    return $(this).attr("data-fids") || "";
                }).get().join("; ")
            }, 0, "swload_frame");
        },
        // 上传 
        upload : function(input, index) {
            if(!isCorrectType(input, index)) {
                cur_options.onError(301);
                return ;
            }
            if(input.files) {
                if(input.files.length < 1) return ;
            } else {
                if(input.value == '') return ;
            }
            $(input).hide();
            $cur_containers.eq(index).addClass("loading upload");
            $(input).closest("form").submit().remove();
            var key = $cur_containers.eq(index).data("data-key");
            _swfile_acts.progress(key, index);
        },
        // 获取进度
        progress : function(key, index) {
            $cur_containers.eq(index).find("li.add>.bar").show();
            sendRequest("/progress", {
                key : key,
                index : index,
                proxy : cur_options.proxy
            }, index, "swprogress_frame");
        },
        // 预览
        preview : function($container, id) {
            var params = "id=" + id +
                        "&key=" + $container.data("data-key") +
                        "&proxy=" + cur_options.proxy;
            var url = CONSTANTS.URL_PREFIX + "/preview?" + params;
            cur_options.onPreview(url, function() { // 下载
                _swfile_acts.download($container, id);
            }, canEdit($container) ? function() { // 删除
                _swfile_acts.del($container, id);
            } : null);
        },
        // 删除
        del : function($container, id) {
            var key = $container.data("data-key");
            sendRequest("/delete", {
                id : id,
                key : key,
                proxy : cur_options.proxy
            }, 0, "swdelete_frame_" + key + "_" + id);
        },
        // 下载
        download : function($container, id) {
            sendRequest("/download", {
                id : id,
                key : $container.data("data-key")
            }, 0, "swdownload_frame");
            cur_options.onDownload(id);
        }
    };
    
    // 回调方法（公共）
    _swfile_cbs = {
        // 初始化回调
        onInit : function(data) {
            var obj = eval("(" + data + ")");
            ftype = obj.ftype;
            // 隐藏cache_key
            $('<input type="hidden" name="' + CONSTANTS.CACHE_KEY + '" />').val(obj.key).insertBefore($cur_containers.first());
            $cur_containers.removeClass("loading load");
            $cur_containers.data("data-key", obj.key);
//            $('iframe[name="swinit_frame"]', idocs[0]).remove();
            cur_options.onInit();
            _swfile_acts.load();
        },
        // 加载回调
        onLoad : function(data) {
            var obj = eval("(" + data + ")");
            $.each(obj.files, function(i, files) {
                var $container = $cur_containers.eq(i);
                createLi($container, files);
                $container.removeClass("loading load");
                createUploadForm($container);
            });
//            $('iframe[name="swload_frame"]', idocs[0]).remove();
            cur_options.onLoad(obj.files);
        },
        // 上传回调
        onUpload : function(data) {
            var obj = eval("(" + data + ")");
            var $container = $cur_containers.eq(obj.index);
            $container.removeClass("loading upload");
//            $('iframe[name="swupload_frame"]', idocs[obj.index]).remove();
            $container.find("li.add>.bar").hide().find(">.progress").css("width", "0%");
            createUploadForm($container);
            createLi($container, obj.files);
            cur_options.onUpload(obj.files);
        },
        // 获取进度回调
        onProgress : function(data) {
            var obj = eval("(" + data + ")");
            var $container = $cur_containers.eq(obj.index);
            var percent = obj.progress.contentLength == 0 ? 0 : parseInt(obj.progress.bytesRead / obj.progress.contentLength * 100);
            var s = parseInt("cc", 16), // 当前背景色
                e = parseInt("55", 16), // 目标背景色
                d = s - parseInt(percent / 100 * (s - e)),
                c = d.toString(16),
                bgc = "#" + c + c + c;
            $container.find("li.add>.bar")
                .find(">.text").html(percent + "%").end()
                .find(">.progress").stop().animate({
                    "width" : percent + "%"
                }, 100, function() {
                    $(this).css({"background-color" : bgc});
                });
//            $('iframe[name="swprogress_frame"]', idocs[obj.index]).remove();
            if(percent < 100) {
                _swfile_acts.progress(obj.key, obj.index);
            }
        },
        // 删除回调
        onDelete : function(data) {
            var obj = eval("(" + data + ")");
            var $li = $("b#" + obj.file.id).parent();
            var $container = $li.parent().parent();
            $li.remove();
            limitHide($container);
//            $('iframe[name="swdelete_frame"]', idocs[0]).remove();
            cur_options.onDelete(obj.file); // 回调
        }
    };
    // 初始化html结构
    var initHtml = function() {
        $cur_containers
        .addClass(CONSTANTS.CONTAINER_CLASS)
        .addClass(cur_options.theme)
        .each(function() {
            var $container = $(this);
            var $iframe = $('<iframe></iframe>').css(css);
            $('<li></li>')
                .addClass("add")
                .append($('<b></b>').append($iframe))
                .append('<div class="bar"><div class="progress"></div><div class="text"></div></div>')
                .wrap('<ul></ul>')
                .parent()
                .appendTo($container);
            var idoc = $iframe[0].contentDocument;
            idocs.push(idoc);
        });
    };
	// 创建html
	var createUploadForm = function($container) {
        var key = $container.data("data-key");
        var index = $cur_containers.index($container);
        var $div = $('<div></div>');
        var idoc = idocs[index];
        var $target = $('<iframe></iframe>').attr("name", "swupload_frame").hide();
        if($('iframe[name="swupload_frame"]', idoc).length < 1) {
            $div.append($target);
        }
        var $form = $('<form></form>')
            .css(css)
            .attr({
                "enctype" : "multipart/form-data",
                "method" : "post",
                "target" : "swupload_frame",
                "action" : CONSTANTS.URL_PREFIX + "/upload?" + key + "-" + index
            })
            .append('<input name="key" type="hidden" value="' + key + '" />')
            .append('<input name="project" type="hidden" value="' + cur_options.project + '" />')
            .append('<input name="module" type="hidden" value="' + $container.attr("data-module") + '" />')
            .append('<input name="proxy" type="hidden" value="' + cur_options.proxy + '" />')
            .append('<input name="index" type="hidden" value="' + index + '" />')
            .append($('<input type="file" name="file"' + (cur_options.multiple ? ' multiple="multiple"' : '') + ' />')
            .css(css));
        idoc.write($div.append($form).html());
        $(idoc.body).css(css); // 清除iframe内body的间距
        $('input[type="file"]', idoc).change(function(e) {
            _swfile_acts.upload(this, $(idoc).find('input[name="index"]').val());
        });
	};
    // 创建缩略图块
    var createLi = function($container, files) {
        $.each(files, function(i, file) {
            var name = decodeURI(file.encodeName);
            var $li = $('<li><b id="' + file.id + '" class="' + file.ftype + '">' +
                    (file.ftype == "image" ? '<img src="' + cur_options.server + "/" + file.webPath + '" />' : '') +
                    '</b>' +
                    '<span title="' + name + '">' + name + '</span>' +
                    '<i>' +
                    '<a class="download" href="javascript:;" title="下载"></a>' +
                    (canEdit($container) ? '<a class="delete" href="javascript:;" title="删除"></a>' : '') +
                    '</i>' +
            '</li>').find(">b").click(function() { // 预览
                _swfile_acts.preview($container, $(this).attr("id"));
            }).end().find(">i>a.download").click(function() { // 下载
                _swfile_acts.download($container, $(this).parent().siblings("b").attr("id"));
            }).end().find(">i>a.delete").click(function() { // 删除
                _swfile_acts.del($container, $(this).parent().siblings("b").attr("id"));
            }).end();
            $li.find("img").error(function() {
                $(this).replaceWith('<div class="error"></div>');
            });
            $container.find("li.add").before($li);
            limitHide($container);
        });
    };
    // 发送异步请求（通过iframe表单）
    var sendRequest = function(url, data, index, target) {
        var $div = $('<div></div>');
        var $target = $('<iframe></iframe>').attr("name", target).hide();
        if($('iframe[name="' + target + '"]', idocs[index]).length < 1) {
            $div.append($target);
        }
        var $form = $('<form></form>').attr({
            "id" : "ajax_form",
            "method" : "post",
            "target" : target,
            "action" : CONSTANTS.URL_PREFIX + url
        });
        $.each(data, function(k, v) {
            $form.append('<input type="hidden" name="' + k + '" value="' + v + '"/>');
        });
        $div.append($form);
        idocs[index].write($div.html());
//console.log($("body", idocs[index]).html());
        $("form#ajax_form", idocs[index]).submit().remove();
    };
    // 判断是否可编辑
    var canEdit = function($container) {
    	return !$container.hasClass(CONSTANTS.NO_EDIT);
    };
    // 判断文件类型是否合法
    var isCorrectType = function(input, index) {
		var type = ($cur_containers.eq(index).attr("data-type") || "").split(",");
		var typelist = [];
		for(var i in type) {
			typelist = typelist.concat(ftype[type[i].replace(/(^\s*)|(\s*$)/g, "")]);
		}
		var contain = function(array, e) {
			for(var i = 0; i < array.length; i ++) {
				if(array[i] == e) return true;
			}
			return false;
		};
		var suffix = function(name) {
		    return name.substring(name.lastIndexOf(".") + 1).toLowerCase();
		};
		if(input.files) {
		    for(var i = 0; i < input.files.length; i ++) {
		        if(!contain(typelist, suffix(input.files[i].name))) return false;
		    }
		} else { // ie8
            if(!contain(typelist, suffix(input.value))) return false;
		}
    	return true;
    };
    // 此区域超过最大限制文件数，则隐藏添加按钮
    var limitHide = function($container) {
    	var limit = $container.attr("data-limit");
    	limit = typeof(limit) == "undefined" ? CONSTANTS.MAX_LIMIT : parseInt(limit);
		if($container.find("li:not(li.add)").length >= limit) {
			$container.find("li.add").hide();
		} else {
			$container.find("li.add").show();
		}
    };
})(jQuery);
//动态引入css
$("script").last().each(function() {
	var root = function(){var a=location.href;var b=location.pathname;var c=a.substring(0,a.indexOf(b));var d=b.substring(0,b.substr(1).indexOf('/')+1);return c+d+"/";}();
	var path = $(this).attr("src");
	path = path.substr(0, path.lastIndexOf('/') + 1);
	$("<link>").attr({
		rel : "stylesheet",
		type : "text/css",
		href : root + path + "swfile.skin.css"
	}).insertAfter($(this));
	$("<link>").attr({
		rel : "stylesheet",
		type : "text/css",
		href : root + path + "swfile.css"
	}).insertAfter($(this));
});
