
/**
 * 示例Action类
 * @author Xiaojie.Xu
 */
public class DemoAction extends BaseAction {
    
    /**
     * 添加页面
     */
    public void add(Rundata map) {
        map.addForward("/urp/urp/file/add.jsp");
    }
    
    /**
     * 添加业务数据
     */
    public void doAdd(Rundata map) {
        // 模拟生成业务数据id
        String bid = UUID.randomUUID().toString().replace("-", "");
        String result = FileTracker.synchronize(map.getHttpServletRequest(), bid);
System.out.println(result);
        map.addRedirect("AccessoryAction.add.act");
    }
    
    /**
     * 编辑页面
     */
    public void edit(Rundata map) {
        String id = map.getString("id");
        map.getRequest().setAttribute("id", id);
        map.addForward("/urp/urp/file/edit.jsp");
    }
    
    /**
     * 编辑业务数据
     */
    public void doEdit(Rundata map) {
        String id = map.getString("id");
        String result = FileTracker.synchronize(map.getHttpServletRequest(), id);
System.out.println(result);
        map.addRedirect("AccessoryAction.edit.act?id=" + id);
    }
}